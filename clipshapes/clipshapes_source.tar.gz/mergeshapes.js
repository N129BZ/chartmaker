import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';

const INPUT_DIR = path.resolve('./clipshapes');
const OUTPUT_FILE = path.resolve('./clipshapes.geojson');

function findShapefiles(dir) {
  let results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(findShapefiles(fullPath));
    } else if (entry.isFile() && entry.name.toLowerCase().endsWith('.shp')) {
      results.push(fullPath);
    }
  }
  return results.sort();
}

function normalizeName(rawName) {
  return rawName
    .toLowerCase()
    .replace(/[- ]+/g, '_')
    .replace(/'/g, '');
}

function mergeClipshapes() {
  if (fs.existsSync(OUTPUT_FILE)) {
    fs.unlinkSync(OUTPUT_FILE);
  }

  const shapefiles = findShapefiles(INPUT_DIR);
  console.log(`Merging ${shapefiles.length} chart clipshapes into ${OUTPUT_FILE}...\n`);

  shapefiles.forEach((shpPath, index) => {
    const rawBaseName = path.basename(shpPath, path.extname(shpPath));
    const chartName = normalizeName(rawBaseName);

    // Extract the subfolder path relative to ./clipshapes
    const relDir = path.relative(INPUT_DIR, path.dirname(shpPath));
    const chartCategory = relDir ? normalizeName(relDir.split(path.sep).join('_')) : 'default';

    const sqlChartName = chartName.replace(/'/g, "''");
    const sqlCategory = chartCategory.replace(/'/g, "''");
    const layerName = rawBaseName.replace(/"/g, '""');

    const sql = `SELECT *, '${sqlChartName}' AS chart_name, '${sqlCategory}' AS chart_category FROM "${layerName}"`;

    const args = [
      '-f', 'GeoJSON',
      '-t_srs', 'EPSG:4326',
      '-lco', 'COORDINATE_PRECISION=6',
      '-nln', 'clipshapes',
      '-sql', sql,
    ];

    if (index > 0) {
      args.push('-update', '-append');
    }

    args.push(OUTPUT_FILE, shpPath);

    execFileSync('ogr2ogr', args, { stdio: 'pipe' });
  });

  console.log(`Done! Merged ${shapefiles.length} features.`);
}

mergeClipshapes();

